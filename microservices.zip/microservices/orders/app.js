const express = require("express");
const app = express();
const mongoose = require('mongoose');
const {productDetailsModel} = require('./models/ordersModel');

app.get("/",(req,res)=>{
    res.send("Orders");
});

app.get("/test",(req,res)=>{
    res.send("Testing");
});

app.get("/fetch",async (req,res)=>{
    console.log("hit in fetch")
    try{
        const result = await productDetailsModel.find({});
        console.log(result);
        res.status(200).send({productDetails: result,msg:"Data fetch sucessfull", status:true});
    }
    catch(err){
        res.status(404).send({err:err, msg:"Data fetch unsucessfull", status: false});
    }
}
);

mongoose.connect("mongodb://localhost:27017/shopping-kart").then((res)=> console.log("DB connected Sucessfully")).catch((err)=>console.log(err));

module.exports = app;