const express = require("express");
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const bp = require('body-parser');
const dashboardRoute = require('./routes/dashboardRoutes');

app.use(bp.json());
app.use(cors());
app.use("/",dashboardRoute);

mongoose.connect("mongodb://localhost:27017/shopping-kart").then((res)=> console.log("DB connected Sucessfully")).catch((err)=>console.log(err));

module.exports = app;