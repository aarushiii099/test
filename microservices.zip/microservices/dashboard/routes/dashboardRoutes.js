const express = require("express");
const router = express.Router();
const Controllers = require('../controllers/dashboardControllers');

router.get("/",(req,res)=>{
    res.send("Dashboard");
});

router.get("/productDetails", Controllers.fetchData);

router.post("/createProduct", Controllers.createProduct);

router.get("/productData/:id", Controllers.productData);

module.exports = router;