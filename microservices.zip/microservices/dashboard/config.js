let config = {
    PORT : 3002
};
module.exports = config;