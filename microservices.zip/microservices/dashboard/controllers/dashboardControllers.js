const { productDetailsModel } = require('../models/dashboardModel');

const Controllers = {};



Controllers.createProduct = async function(req,res){
    const data = req.body;
    try{
        const result = await productDetailsModel.create({
            productId: data.productId,
            pname: data.pname,
            price: data.price
        });
        res.status(200).send({msg:"product creation sucessfull", status:true});
    }
    catch(err){
        res.status(404).send({msg:"product creation Unsucessfull",status:false, err: err});
    }
}

Controllers.fetchData = async function(req,res){
    try{
        const result = await productDetailsModel.find({});
        res.status(200).send({productDetails: result,msg:"Data fetch sucessfull", status:true});
    }
    catch(err){
        res.status(404).send({err:err, msg:"Data fetch unsucessfull", status: false});
    }
}

Controllers.productData = async function(req,res){
    try{
        const id = req.params.id;
        const result = await productDetailsModel.findOne({productId: id});
        res.status(200).send({productData: result,msg:"Product data fetched sucessfully", status:true});
    }
    catch(err){
        res.status(404).send({msg:"fetch unsucessful",status:false})
    }
}

module.exports = Controllers;