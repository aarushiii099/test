const express=require("express")
const app=express()
const {createProxyMiddleware}=require("http-proxy-middleware")
const config=require("./config")

app.use("/dashboard", createProxyMiddleware({
    target: config.dashboardService_URL,
    pathRewrite:{
        '^/dashboard':'/'
    },
    changeOrigin: true
}));

app.use("/orders", createProxyMiddleware({
    target: config.ordersService_URL,
    pathRewrite:{
        '^/orders':'/'
    },
    changeOrigin:true
}));

app.use("/oders/test", createProxyMiddleware({
    target: config.ordersService_URL,
    pathRewrite:{
        '^/orders/test':'/test'
    },
    changeOrigin: true
}))

module.exports=app;