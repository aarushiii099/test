let config={
    WWW_PORT:3001,
    dashboardService_URL:"http://localhost:3002",
    ordersService_URL:"http://localhost:3003"
}
module.exports=config;